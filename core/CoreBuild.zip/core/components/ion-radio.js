/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import { R as Radio, d as defineCustomElement$1 } from './radio.js';

const IonRadio = Radio;
const defineCustomElement = defineCustomElement$1;

export { IonRadio, defineCustomElement };
