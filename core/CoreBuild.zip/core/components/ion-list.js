/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import { L as List, d as defineCustomElement$1 } from './list.js';

const IonList = List;
const defineCustomElement = defineCustomElement$1;

export { IonList, defineCustomElement };
