/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
import { S as SelectPopover, d as defineCustomElement$1 } from './select-popover.js';

const IonSelectPopover = SelectPopover;
const defineCustomElement = defineCustomElement$1;

export { IonSelectPopover, defineCustomElement };
