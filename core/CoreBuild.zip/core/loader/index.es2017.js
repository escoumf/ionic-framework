/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
export * from '../dist/esm/polyfills/index.js';
export * from '../dist/esm/loader.js';
