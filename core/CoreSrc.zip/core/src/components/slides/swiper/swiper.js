import { Autoplay, Pagination, Scrollbar, Swiper, Keyboard, Zoom } from 'swiper/js/swiper.esm';

Swiper.use([Pagination, Scrollbar, Autoplay, Keyboard, Zoom]);
export { Swiper };
