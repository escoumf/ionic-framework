export { Swiper as SwiperInterface, SwiperOptions } from 'swiper/js/swiper.esm';
