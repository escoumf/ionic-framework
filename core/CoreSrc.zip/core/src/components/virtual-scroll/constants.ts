export const CELL_TYPE_ITEM = 'item';
export const CELL_TYPE_HEADER = 'header';
export const CELL_TYPE_FOOTER = 'footer';

export const NODE_CHANGE_NONE = 0;
export const NODE_CHANGE_POSITION = 1;
export const NODE_CHANGE_CELL = 2;
