# ion-picker-column



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description        | Type           | Default     |
| -------- | --------- | ------------------ | -------------- | ----------- |
| `col`    | --        | Picker column data | `PickerColumn` | `undefined` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
